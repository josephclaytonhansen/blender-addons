bl_info = {
    "name": "ShotDial",
    "author": "Joseph Hansen",
    "version": (1, 3, 39),
    "blender": (3, 60, 13),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "https://github.com/josephclaytonhansen/blender-addons",
    "category": "3D View"
}

import bpy
import random
from bpy.props import StringProperty, FloatVectorProperty, CollectionProperty, BoolProperty
from bpy.app.handlers import persistent
from .panel import SHOTDIAL_PT_ShotPanel
from .spin_operators import OBJECT_OT_Spin, OBJECT_OT_DeSpin
from .rename_shot import SHOTDIAL_OT_RenameShot
from .remove_shot import SHOTDIAL_OT_RemoveShot
from .append_node_group import append_node_group

def update_shot_name(self, context):
    bpy.ops.shotdial.rename_shot(new_name=self.name)

class ShotData(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", default="Shot", update=update_shot_name)
    color: FloatVectorProperty(name="Color", subtype='COLOR', min=0, max=1, default=(1.0, 1.0, 1.0))
    camera: bpy.props.PointerProperty(type=bpy.types.Object)

camera_index = 0
addon_keymaps = []
shotdial_node_group = None

@persistent
def load_handler(dummy):
    append_node_group()

class SHOTDIAL_OT_NewShot(bpy.types.Operator):
    """Add a new shot"""
    bl_idname = "shotdial.new_shot"
    bl_label = "New Shot"

    def execute(self, context):
        if context.scene.camera:
            cam_obj = context.scene.camera
        else:
            cam_data = bpy.data.cameras.new(name="Camera")
            cam_obj = bpy.data.objects.new(name="Camera", object_data=cam_data)
            context.scene.collection.objects.link(cam_obj)
            context.scene.camera = cam_obj

        shot_name = f"Shot {len(context.scene.shotdial_shots) + 1}"
        shot_color = (random.random(), random.random(), random.random())
        new_shot = context.scene.shotdial_shots.add()
        new_shot.name = shot_name
        new_shot.color = shot_color
        new_shot.camera = cam_obj
        cam_obj.name = shot_name

        shot_check_mat = bpy.data.materials.get("ShotCheck") or bpy.data.materials.new("ShotCheck")
        shot_check_mat.use_nodes = True

        shot_check_mat.diffuse_color = (*shot_color, 1.0)

        for obj in context.scene.objects:
            if obj.type != 'MESH' or obj.hide_render:
                continue
            else:
                if not obj.modifiers.get("ShotCheck"):
                    modifier = obj.modifiers.new(name="ShotCheck", type='NODES')
                    global shotdial_node_group
                    modifier.node_group = shotdial_node_group

        self.report({'INFO'}, f"Shot '{shot_name}' created")
        return {'FINISHED'}

class SHOTDIAL_OT_SetActiveCamera(bpy.types.Operator):
    """Set the active camera for the selected shot"""
    bl_idname = "shotdial.set_active_camera"
    bl_label = "Set Active Camera"
    
    shot_name: StringProperty()

    def execute(self, context):
        shot = next((s for s in context.scene.shotdial_shots if s.name == self.shot_name), None)
        if shot:
            cam_obj = shot.camera
            if cam_obj:
                context.scene.camera = cam_obj
                bpy.ops.view3d.view_camera()
                self.report({'INFO'}, f"Set '{shot.name}' as active camera")
            else:
                self.report({'ERROR'}, "Camera not found")
        else:
            self.report({'ERROR'}, "Shot not found")
        return {'FINISHED'}

classes = [
    ShotData,
    SHOTDIAL_OT_NewShot,
    SHOTDIAL_PT_ShotPanel,
    SHOTDIAL_OT_SetActiveCamera,
    OBJECT_OT_Spin,
    OBJECT_OT_DeSpin,
    SHOTDIAL_OT_RenameShot,
    SHOTDIAL_OT_RemoveShot
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.shotdial_shots = CollectionProperty(type=ShotData)
    bpy.app.handlers.load_post.append(load_handler)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.shotdial_shots
    bpy.app.handlers.load_post.remove(load_handler)


if __name__ == "__main__":
    register()