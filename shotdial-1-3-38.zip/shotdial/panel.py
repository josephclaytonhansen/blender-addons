import bpy

def update_shot_name(self, context):
    bpy.ops.shotdial.rename_shot(new_name=self.name)

class SHOTDIAL_PT_ShotPanel(bpy.types.Panel):
    bl_label = "ShotDial Panel"
    bl_idname = "SHOTDIAL_PT_shot_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ShotDial'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.operator("shotdial.new_shot", text="New Shot")

        for shot in scene.shotdial_shots:
            box = layout.box()
            row = box.row()
            row.prop(shot, "name", text="")
            row.prop(shot, "color", text="Color")
            row = box.row()
            split = row.split(factor=0.8)
            col = split.column()
            op = col.operator("shotdial.set_active_camera", text="Preview")
            op.shot_name = shot.name
            col = split.column()
            col.operator("shotdial.remove_shot", text="", icon='TRASH').shot_name = shot.name

def register():
    bpy.utils.register_class(SHOTDIAL_PT_ShotPanel)

def unregister():
    bpy.utils.unregister_class(SHOTDIAL_PT_ShotPanel)

if __name__ == "__main__":
    register()