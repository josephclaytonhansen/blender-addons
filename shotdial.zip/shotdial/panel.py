import bpy

class SHOTDIAL_PT_ShotPanel(bpy.types.Panel):
    bl_label = "ShotDial Panel"
    bl_idname = "SHOTDIAL_PT_shot_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ShotDial'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.operator("shotdial.new_shot", text="New Shot")

        for shot in scene.shotdial_shots:
            box = layout.box()
            row = box.row()
            row.prop(shot, "name", text="")
            row.operator("shotdial.rename_shot", text="Rename").new_name = shot.name
            row = box.row()
            row.prop(shot, "color", text="Color")
            row = box.row()
            op = row.operator("shotdial.set_active_camera", text="Preview")
            op.shot_name = shot.name
            remove = row.operator("shotdial.remove_shot", text="", icon='TRASH')
            remove.shot_name = shot.name
            remove.scale_x = 0.5
            