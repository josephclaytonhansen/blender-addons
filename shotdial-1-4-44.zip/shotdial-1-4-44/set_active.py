import bpy
from bpy.props import StringProperty

class SHOTDIAL_OT_SetActiveCamera(bpy.types.Operator):
    """Set the active camera for the selected shot"""
    bl_idname = "shotdial.set_active_camera"
    bl_label = "Set Active Camera"
    
    shot_name: StringProperty()

    def execute(self, context):
        shot = next((s for s in context.scene.shotdial_shots if s.name == self.shot_name), None)
        if shot:
            cam_obj = shot.camera
            if cam_obj:
                context.scene.camera = cam_obj
                bpy.ops.view3d.view_camera()
                
                # Show all mesh objects
                for obj in context.scene.objects:
                    if obj.type == 'MESH':
                        obj.hide_set(False)
                        obj.hide_viewport = False

                # Hide objects not visible in the shot
                prop_name = f"shot_visibility_{self.shot_name}"
                for obj in context.scene.objects:
                    if obj.type == 'MESH' and obj.get(prop_name) == 0:
                        obj.hide_set(True)
                        obj.hide_viewport = True

                self.report({'INFO'}, f"Set '{shot.name}' as active camera")
            else:
                self.report({'ERROR'}, "Camera not found")
        else:
            self.report({'ERROR'}, "Shot not found")
        return {'FINISHED'}